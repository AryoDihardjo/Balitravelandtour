<?php

/**
 * Single Post Options
 *
 * @package travel_vacation
 */

$wp_customize->add_section(
	'travel_vacation_single_post_options',
	array(
		'title' => esc_html__( 'Single Post Options', 'travel-vacation' ),
		'panel' => 'travel_vacation_theme_options',
	)
);


// Post Options - Show / Hide Date.
$wp_customize->add_setting(
	'travel_vacation_single_post_hide_date',
	array(
		'default'           => true,
		'sanitize_callback' => 'travel_vacation_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Travel_Vacation_Toggle_Switch_Custom_Control(
		$wp_customize,
		'travel_vacation_single_post_hide_date',
		array(
			'label'   => esc_html__( 'Show / Hide Date', 'travel-vacation' ),
			'section' => 'travel_vacation_single_post_options',
		)
	)
);

// Post Options - Show / Hide Author.
$wp_customize->add_setting(
	'travel_vacation_single_post_hide_author',
	array(
		'default'           => true,
		'sanitize_callback' => 'travel_vacation_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Travel_Vacation_Toggle_Switch_Custom_Control(
		$wp_customize,
		'travel_vacation_single_post_hide_author',
		array(
			'label'   => esc_html__( 'Show / Hide Author', 'travel-vacation' ),
			'section' => 'travel_vacation_single_post_options',
		)
	)
);

// Post Options - Show / Hide Comments.
$wp_customize->add_setting(
	'travel_vacation_single_post_hide_comments',
	array(
		'default'           => true,
		'sanitize_callback' => 'travel_vacation_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Travel_Vacation_Toggle_Switch_Custom_Control(
		$wp_customize,
		'travel_vacation_single_post_hide_comments',
		array(
			'label'   => esc_html__( 'Show / Hide Comments', 'travel-vacation' ),
			'section' => 'travel_vacation_single_post_options',
		)
	)
);

// Post Options - Show / Hide Time.
$wp_customize->add_setting(
	'travel_vacation_single_post_hide_time',
	array(
		'default'           => true,
		'sanitize_callback' => 'travel_vacation_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Travel_Vacation_Toggle_Switch_Custom_Control(
		$wp_customize,
		'travel_vacation_single_post_hide_time',
		array(
			'label'   => esc_html__( 'Show / Hide Time', 'travel-vacation' ),
			'section' => 'travel_vacation_single_post_options',
		)
	)
);

// Post Options - Show / Hide Category.
$wp_customize->add_setting(
	'travel_vacation_single_post_hide_category',
	array(
		'default'           => true,
		'sanitize_callback' => 'travel_vacation_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Travel_Vacation_Toggle_Switch_Custom_Control(
		$wp_customize,
		'travel_vacation_single_post_hide_category',
		array(
			'label'   => esc_html__( 'Show / Hide Category', 'travel-vacation' ),
			'section' => 'travel_vacation_single_post_options',
		)
	)
);

// Post Options - Show / Hide Tag.
$wp_customize->add_setting(
	'travel_vacation_post_hide_tags',
	array(
		'default'           => true,
		'sanitize_callback' => 'travel_vacation_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Travel_Vacation_Toggle_Switch_Custom_Control(
		$wp_customize,
		'travel_vacation_post_hide_tags',
		array(
			'label'   => esc_html__( 'Show / Hide Tag', 'travel-vacation' ),
			'section' => 'travel_vacation_single_post_options',
		)
	)
);

// Post Options - Comment Title.
$wp_customize->add_setting(
	'travel_vacation_blog_post_comment_title',
	array(
		'default'=> 'Leave a Reply',
		'sanitize_callback'	=> 'sanitize_text_field'
	)
);

$wp_customize->add_control(
	'travel_vacation_blog_post_comment_title',
	array(
		'label'	=> __('Comment Title','travel-vacation'),
		'input_attrs' => array(
			'placeholder' => __( 'Leave a Reply', 'travel-vacation' ),
		),
		'section'=> 'travel_vacation_single_post_options',
		'type'=> 'text'
	)
);